CURSO: K3014

NUMERO DE GRUPO: 41

INTEGRANTES:
- Aguerrido Joaqu�n 152.105-6
- Pirotte Daniela 152.318-1
- Pulleiro Gast�n 143.970-4
- Rombol� Juli�n 152.309-0

MAIL RESPONSABLE: julian.rombola@outlook.com